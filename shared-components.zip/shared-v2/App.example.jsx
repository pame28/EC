// App.example.jsx
import { useState } from "react";
import "./shared/tokens.css"; // se importa UNA vez, aquí en la raíz
import { Heading, Text, Button, Badge, Navbar, Sidebar, TeamCard } from "./shared/components";
import { Check, ArrowRight } from "lucide-react";

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [active, setActive] = useState("lideres");

  return (
    <div className="app-root">
      <Navbar onMenuClick={() => setSidebarOpen((v) => !v)} />

      <div style={{ display: "flex" }}>
        <Sidebar
          open={sidebarOpen}
          active={active}
          onSelect={(k) => {
            setActive(k);
            setSidebarOpen(false);
          }}
        />

        <main style={{ flex: 1, padding: "28px 24px", maxWidth: 1180, margin: "0 auto", width: "100%" }}>
          <Heading level={1}>Mantenimiento de líder</Heading>
          <Text variant="body" style={{ marginTop: 6, marginBottom: 24 }}>
            Crea y administra equipos de trabajo por área.
          </Text>

          <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
            <Button variant="primary" size="md" icon={Check}>Nuevo equipo</Button>
            <Button variant="secondary" size="md">Gestión de líderes</Button>
            <Button variant="tertiary" size="md" icon={ArrowRight}>Ver reportes</Button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 18 }}>
            <TeamCard
              area="HN - Agencias"
              name="Equipo La Ceiba A"
              leader="Ana Rodríguez"
              members={[
                { name: "Jorge Flores", role: "Cajero — La Ceiba", status: "activo", statusLabel: "Activo" },
                { name: "Miguel Torres", role: "Cajero — La Ceiba", status: "vacaciones", statusLabel: "Vacaciones" },
                { name: "Pedro Álvarez", role: "Cajero — Tegucigalpa Norte", status: "inactivo", statusLabel: "Inactivo" },
              ]}
            />
            <TeamCard
              area="HN - Agencias"
              name="Equipo SPS Norte"
              leader="Jorge Mendoza"
              members={[
                { name: "Patricia Reyes", role: "Asesora — SPS", status: "activo", statusLabel: "Activo" },
                { name: "Sofía Gutiérrez", role: "Asesora — SPS Sur", status: "activo", statusLabel: "Activo" },
              ]}
            />
          </div>

          <div style={{ marginTop: 24, display: "flex", gap: 10 }}>
            <Badge status="activo">Activo</Badge>
            <Badge status="vacaciones">Vacaciones</Badge>
            <Badge status="inactivo">Inactivo</Badge>
          </div>
        </main>
      </div>
    </div>
  );
}
