// shared/components/Typography/index.js
export { Heading, Text } from "./Typography";
