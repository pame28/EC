// shared/components/Typography/Typography.jsx
import styles from "./Typography.module.css";

/**
 * <Heading level={1|2|3|4}>Texto</Heading>
 */
export function Heading({ level = 1, children, className = "" }) {
  const Tag = `h${level}`;
  return <Tag className={`${styles[`h${level}`]} ${className}`}>{children}</Tag>;
}

/**
 * <Text variant="body|muted|label">Texto</Text>
 */
export function Text({ variant = "body", children, className = "" }) {
  return <p className={`${styles[variant]} ${className}`}>{children}</p>;
}
