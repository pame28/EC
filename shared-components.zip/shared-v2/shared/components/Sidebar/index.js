// shared/components/Sidebar/index.js
export { Sidebar, NAV_ITEMS } from "./Sidebar";
