// shared/components/Sidebar/Sidebar.jsx
import { LayoutDashboard, Users, UserCog, BarChart3, Settings, LogOut } from "lucide-react";
import styles from "./Sidebar.module.css";

// Edita esta lista para cambiar las opciones del menú.
export const NAV_ITEMS = [
  { key: "dashboard", label: "Panel general", icon: LayoutDashboard },
  { key: "usuarios", label: "Mantenimiento de usuarios", icon: Users },
  { key: "lideres", label: "Mantenimiento de líder", icon: UserCog },
  { key: "reportes", label: "Reportes", icon: BarChart3 },
  { key: "config", label: "Configuración", icon: Settings },
];

/**
 * <Sidebar open={bool} active="key" onSelect={(key) => {}} items={NAV_ITEMS} />
 */
export function Sidebar({ open, active, onSelect, items = NAV_ITEMS }) {
  return (
    <>
      {open && <div className={styles.overlay} onClick={() => onSelect(active)} />}
      <aside className={`${styles.sidebar} ${open ? styles.open : ""}`}>
        <span className={styles.label}>MÓDULO</span>
        {items.map(({ key, label, icon: Icon }) => (
          <div
            key={key}
            className={`${styles.navlink} ${active === key ? styles.active : ""}`}
            onClick={() => onSelect(key)}
          >
            <Icon size={17} strokeWidth={2.25} />
            {label}
          </div>
        ))}
        <div className={styles.footer}>
          <div className={styles.navlink}>
            <LogOut size={17} /> Cerrar sesión
          </div>
        </div>
      </aside>
    </>
  );
}
