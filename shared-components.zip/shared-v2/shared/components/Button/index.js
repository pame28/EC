// shared/components/Button/index.js
export { Button } from "./Button";
