// shared/components/Button/Button.jsx
import styles from "./Button.module.css";

/**
 * <Button variant="primary|secondary|tertiary" size="sm|md|lg" icon={LucideIcon}>
 *   Texto
 * </Button>
 */
export function Button({ variant = "primary", size = "md", icon: Icon, children, ...props }) {
  return (
    <button className={`${styles.btn} ${styles[variant]} ${styles[size]}`} {...props}>
      {Icon && <Icon size={16} strokeWidth={2.25} />}
      {children}
    </button>
  );
}
