// shared/components/index.js
// Punto de entrada único:
//   import { Button, Navbar, Sidebar, Heading, Text, Badge, TeamCard } from "@/shared/components";

export { Navbar } from "./Navbar";
export { Sidebar, NAV_ITEMS } from "./Sidebar";
export { Button } from "./Button";
export { Badge } from "./Badge";
export { Heading, Text } from "./Typography";
export { TeamCard } from "./TeamCard";
