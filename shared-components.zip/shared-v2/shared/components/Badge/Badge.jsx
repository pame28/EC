// shared/components/Badge/Badge.jsx
import styles from "./Badge.module.css";

/**
 * <Badge status="activo|vacaciones|inactivo">Texto</Badge>
 */
export function Badge({ status = "activo", children }) {
  return (
    <span className={`${styles.badge} ${styles[status]}`}>
      <span className={styles.dot} />
      {children}
    </span>
  );
}
