// shared/components/TeamCard/TeamCard.jsx
import { Plus, Pencil, Trash2, RotateCcw, X } from "lucide-react";
import { Heading, Text } from "../Typography";
import { Button } from "../Button";
import { Badge } from "../Badge";
import styles from "./TeamCard.module.css";

function initials(name) {
  return name.split(" ").map((w) => w[0]).slice(0, 2).join("");
}

/**
 * Componente COMPUESTO: arma una tarjeta de equipo usando solo
 * los primitivos de shared/components (Heading, Text, Button, Badge).
 *
 * <TeamCard area="HN - Agencias" name="Equipo La Ceiba A" leader="Ana Rodríguez"
 *   members={[{ name, role, status: "activo|vacaciones|inactivo", statusLabel }]} />
 */
export function TeamCard({ area, name, leader, members, onAddMember, onEditTeam, onDeleteTeam, onChangeLeader }) {
  return (
    <div className={styles.card}>
      <div className={styles.cardHeader}>
        <Text variant="label" className={styles.area}>{area}</Text>
        <div className={styles.headerActions}>
          <button className={styles.iconBtn} onClick={onEditTeam}><Pencil size={15} /></button>
          <button className={styles.iconBtn} onClick={onDeleteTeam}><Trash2 size={15} /></button>
        </div>
      </div>

      <Heading level={3} className={styles.name}>{name}</Heading>

      <div className={styles.leaderRow}>
        <div className={styles.leaderInfo}>
          <div className={styles.leaderAvatar}>{initials(leader)}</div>
          <div>
            <div className={styles.leaderName}>{leader}</div>
            <Text variant="muted">Líder del equipo</Text>
          </div>
        </div>
        <Button variant="tertiary" size="sm" onClick={onChangeLeader}>Cambiar líder</Button>
      </div>

      <div className={styles.membersHeader}>
        <Text variant="label">Miembros ({members.length})</Text>
        <Button variant="primary" size="sm" icon={Plus} onClick={onAddMember}>Agregar</Button>
      </div>

      <div className={styles.memberList}>
        {members.map((m) => (
          <div key={m.name} className={styles.memberRow}>
            <div className={styles.memberInfo}>
              <div className={styles.memberAvatar}>{initials(m.name)}</div>
              <div>
                <div className={styles.memberName}>{m.name}</div>
                <Text variant="muted">{m.role}</Text>
              </div>
            </div>
            <div className={styles.memberActions}>
              <Badge status={m.status}>{m.statusLabel}</Badge>
              <button className={styles.iconBtn}><RotateCcw size={14} /></button>
              <button className={styles.iconBtn}><X size={14} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
