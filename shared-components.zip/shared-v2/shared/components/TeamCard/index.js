// shared/components/TeamCard/index.js
export { TeamCard } from "./TeamCard";
