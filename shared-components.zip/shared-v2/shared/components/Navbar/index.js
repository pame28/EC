// shared/components/Navbar/index.js
export { Navbar } from "./Navbar";
