// shared/components/Navbar/Navbar.jsx
import { Menu, Search, Bell } from "lucide-react";
import styles from "./Navbar.module.css";

/**
 * <Navbar user={{ name, role, initials }} onMenuClick={() => {}} />
 */
export function Navbar({
  user = { name: "Carlos Méndez", role: "Administrador operativo", initials: "CM" },
  onMenuClick,
}) {
  return (
    <header className={styles.header}>
      <div className={styles.brandGroup}>
        <button className={`${styles.iconBtn} ${styles.menuBtn}`} onClick={onMenuClick}>
          <Menu size={20} />
        </button>
        <div className={styles.brand}>
          <div className={styles.logo}>eC</div>
          <span className={styles.brandName}>eCoaching</span>
        </div>
      </div>

      <div className={styles.search}>
        <Search size={16} className={styles.searchIcon} />
        <input className={styles.searchInput} placeholder="Buscar equipo, usuario..." />
      </div>

      <div className={styles.actions}>
        <button className={styles.iconBtn}>
          <Bell size={19} />
        </button>
        <div className={styles.userGroup}>
          <div className={styles.userMeta}>
            <div className={styles.userName}>{user.name}</div>
            <div className={styles.userRole}>{user.role}</div>
          </div>
          <div className={styles.avatar}>{user.initials}</div>
        </div>
      </div>
    </header>
  );
}
