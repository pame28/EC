// shared/tokens.js
// Fuente única de verdad para colores, radios y sombras.

export const colors = {
  azulExperto: "#003865",
  azulFinanciero: "#2D8C9E",
  aquaDigital: "#00C1D4",
  amarilloOptimista: "#FFB81C",
  amarilloEmpatico: "#FDD26E",
  blanco: "#FFFFFF",
  grisNeutro: "#9EA2A2",
};

export const radius = { sm: "6px", md: "10px", lg: "16px" };
export const shadow = "0 1px 2px rgba(0,56,101,0.06), 0 1px 3px rgba(0,56,101,0.08)";

// azulExperto        -> marca, navbar, sidebar, títulos
// azulFinanciero     -> acentos secundarios, etiquetas
// aquaDigital        -> estado "activo", focus, avatares
// amarilloOptimista  -> botón primario / acción principal
// amarilloEmpatico   -> estado "vacaciones" / pendiente
// grisNeutro         -> texto secundario, estado "inactivo"
