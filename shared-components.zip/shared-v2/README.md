# shared/components — estructura con CSS separado por componente

```
src/
  shared/
    tokens.js                     ← colores, radios, sombras (valores JS)
    tokens.css                     ← SOLO variables globales, se importa 1 vez
    components/
      Navbar/
        Navbar.jsx
        Navbar.module.css
        index.js
      Sidebar/
        Sidebar.jsx
        Sidebar.module.css
        index.js
      Button/
        Button.jsx
        Button.module.css
        index.js
      Badge/
        Badge.jsx
        Badge.module.css
        index.js
      Typography/
        Typography.jsx
        Typography.module.css
        index.js
      TeamCard/
        TeamCard.jsx
        TeamCard.module.css
        index.js
      index.js                     ← barrel que junta todos los componentes
  App.example.jsx                  ← pantalla completa ya armada
```

## Por qué esta forma (CSS Modules)

Cada carpeta de componente tiene 3 archivos con el mismo nombre base:
- **`Nombre.jsx`** — la lógica y el marcado.
- **`Nombre.module.css`** — los estilos, con clases normales (`.card`, `.header`...).
- **`index.js`** — para poder importar `from "./Navbar"` en vez de `from "./Navbar/Navbar"`.

Al nombrar el CSS `*.module.css`, el bundler (Vite, Next.js, CRA) le pone automáticamente un nombre único a cada clase por archivo, así que **nunca vas a tener colisiones** entre el `.header` de `Navbar` y un futuro `.header` de otro componente, aunque se llamen igual. Se importa así:

```jsx
import styles from "./Navbar.module.css";
// styles.header, styles.brand, etc.
```

## Import desde afuera

```jsx
import { Navbar, Sidebar, Button, Badge, Heading, Text, TeamCard } from "@/shared/components";
```

El barrel (`shared/components/index.js`) es el único punto de entrada — nadie fuera de `shared/` necesita saber que Navbar vive en su propia subcarpeta.

## Regla para los colores

Los colores de marca **no van escritos en cada `.module.css`** — se usan las variables globales que vienen de `tokens.css` (`var(--navy)`, `var(--gold)`, etc.), definidas una sola vez ahí. Si cambia un color de marca, se edita `tokens.css` y `tokens.js`, y se propaga a todos los componentes automáticamente.

## Si agregas un componente nuevo

1. Crea `shared/components/NombreDelComponente/`.
2. Adentro: `NombreDelComponente.jsx`, `NombreDelComponente.module.css`, `index.js`.
3. Agrégalo al barrel `shared/components/index.js`.

Así cualquier persona del equipo sabe, sin preguntar, dónde buscar el CSS de cualquier pieza: junto a su `.jsx`, nunca en un archivo gigante compartido.
