using EstadosCuentaTC.Dtos;
using EstadosCuentaTC.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;

namespace EstadosCuentaTC.Services
{
    public class GeneracionEstadoCuentaService
    {
        private readonly GeneracionIndividualService _individualService;
        private readonly ILogger<GeneracionEstadoCuentaService> _logger;
        private readonly ILoggerFactory _loggerFactory;
        private readonly JsonRepository _jsonRepo;
        private readonly EstadoCuentaRepository _repo;
        private readonly EncriptacionService _encriptacionService;

        public GeneracionEstadoCuentaService(
            GeneracionIndividualService individualService,
            JsonRepository jsonRepo,
            EstadoCuentaRepository repo,
            ILogger<GeneracionEstadoCuentaService> logger,
            ILoggerFactory loggerFactory,
            IConfiguration config,
            EncriptacionService encriptacionService)
        {
            _individualService  = individualService;
            _logger             = logger;
            _jsonRepo           = jsonRepo;
            _repo               = repo;
            _loggerFactory      = loggerFactory;
            _encriptacionService = encriptacionService;
        }

        public void Ejecutar(ParametrosGeneracionECDto parametros)
        {
            _logger.LogInformation("FASE 4 - GENERACIÓN ESTADOS DE CUENTA");

            if (parametros.TipoGeneracion == "INDIVIDUAL")
            {
                _logger.LogInformation("Modo INDIVIDUAL");

                _individualService.Ejecutar(
                    parametros.RutaArchivoJson,
                    parametros.FechaCorteProcesar
                );
            }
            else if (parametros.TipoGeneracion == "LOTE")
            {
                _logger.LogInformation("Modo LOTE");

                var loteLogger  = _loggerFactory.CreateLogger<GeneracionLoteService>();
                var loteService = new GeneracionLoteService(_repo, loteLogger);

                loteService.Ejecutar(
                    parametros.RutaArchivoJson,
                    parametros.FechaCorteProcesar,
                    parametros.CantidadHilos
                );
            }
            else
            {
                throw new Exception($"TipoGeneracion no válido: {parametros.TipoGeneracion}");
            }

            // ENCRIPTAR (descomentar cuando sea necesario)
            //_encriptacionService.Ejecutar(
            //    parametros.RutaArchivoJson,
            //    parametros.NombreArchivo + parametros.FechaCorteProcesar,
            //    parametros.FechaCorteProcesar,
            //    parametros.LlaveEncripta
            //);
        }
    }
}
