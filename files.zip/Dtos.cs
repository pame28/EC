using System;
using System.Collections.Generic;

namespace EstadosCuentaTC.Dtos
{
    // ── Contenedor del lote completo ────────────────────────────────────────
    public class LoteDatosDto
    {
        public List<EncabezadoDto>        Encabezados     { get; set; } = [];
        public List<DetalleRawDto>        Detalles        { get; set; } = [];
        public List<FinanciamientoRawDto> Financiamientos { get; set; } = [];
        public List<string>               Tarjetas        { get; set; } = [];
    }

    // ── Encabezado (RS1) ────────────────────────────────────────────────────
    public class EncabezadoDto
    {
        public string   No_Tarjeta           { get; set; } = "";
        public string   No_Cuenta            { get; set; } = "";
        public string   Origen               { get; set; } = "";
        public string   Emisor               { get; set; } = "";
        public string   Nombre_TH_Tit        { get; set; } = "";
        public string   Emisor_Madre         { get; set; } = "";
        public string   Cuenta_Madre         { get; set; } = "";
        public string   Nombre_Empresa       { get; set; } = "";
        public string   Tipo_Tarjeta         { get; set; } = "";
        public DateTime? Fecha_Pago          { get; set; }
        public DateTime? Fecha_Corte         { get; set; }
        public decimal  Pago_Contado_MN      { get; set; }
        public decimal  Pago_Minimo_MN       { get; set; }
        public decimal  Saldo_Vencido_MN     { get; set; }
        public decimal  Saldo_Anterior_MN    { get; set; }
        public decimal  Saldo_Final_MN       { get; set; }
        public decimal  Compras_Deb_MN       { get; set; }
        public decimal  Pagos_Cred_MN        { get; set; }
        public decimal  Sobregiro_MN         { get; set; }
        public decimal  Cuota_Mes_MN         { get; set; }
        public decimal  Pago_Contado_ME      { get; set; }
        public decimal  Pago_Minimo_ME       { get; set; }
        public decimal  Saldo_Vencido_ME     { get; set; }
        public decimal  Saldo_Anterior_ME    { get; set; }
        public decimal  Saldo_Final_ME       { get; set; }
        public decimal  Compras_Deb_ME       { get; set; }
        public decimal  Pagos_Cred_ME        { get; set; }
        public decimal  Sobregiro_ME         { get; set; }
        public decimal  Cuota_Mes_ME         { get; set; }
        public string   Moneda_Lim_Cre       { get; set; } = "";
        public decimal  Limite_Credito       { get; set; }
        public decimal  Disponible_Cta_MN    { get; set; }
        public decimal  Disponible_Cta_ME    { get; set; }
        public decimal  Disponible_Ret_MN    { get; set; }
        public decimal  Disponible_Ret_ME    { get; set; }
        public long     PTS_Saldo_Ant        { get; set; }
        public long     PTS_Ganados          { get; set; }
        public long     PTS_Usuados          { get; set; }
        public long     PTS_Saldo_Actual     { get; set; }
        public string   Moneda_Lim_EF        { get; set; } = "";
        public decimal  EF_Limite            { get; set; }
        public decimal  EF_Saldo_MN          { get; set; }
        public decimal  EF_Debitos_MN        { get; set; }
        public decimal  EF_Creditos_MN       { get; set; }
        public decimal  EF_Saldo_ME          { get; set; }
        public decimal  EF_Debitos_ME        { get; set; }
        public decimal  EF_Creditos_ME       { get; set; }
        public decimal  EF_Disponible_MN     { get; set; }
        public decimal  EF_Disponible_ME     { get; set; }
        public decimal  Tasa_Int_Anual_MN    { get; set; }
        public decimal  Tasa_Int_Anual_ME    { get; set; }
        public string   Direccion_1          { get; set; } = "";
        public string   Direccion_2          { get; set; } = "";
        public string   Direccion_3          { get; set; } = "";
        public string   Apdo_Postal          { get; set; } = "";
        public string   Ciudad               { get; set; } = "";
        public string   Mensaje_1            { get; set; } = "";
        public string   Mensaje_2            { get; set; } = "";
        public string   Mensaje_3            { get; set; } = "";
        public string   Mensaje_4            { get; set; } = "";
        public string   Mensaje_5            { get; set; } = "";
        public string   Tarjeta_Imprimir     { get; set; } = "";
        public decimal  Costo_Anual_Tot_MN   { get; set; }
        public decimal  Costo_Anual_Tot_ME   { get; set; }
        public int      Plazo_Canc_Deuda_MN  { get; set; }
        public int      Plazo_Canc_Deuda_ME  { get; set; }
        public decimal  Interes_Pago_Min_MN  { get; set; }
        public decimal  Interes_Pago_Min_ME  { get; set; }
        public string   Correo               { get; set; } = "";
        public decimal  Limite_CreditoMN     { get; set; }
        public decimal  Interes_Corriente_MN { get; set; }
        public decimal  Interes_Corriente_ME { get; set; }
        public string   EstadoTarjeta        { get; set; } = "0";

        // Calculado en .NET (igual que en el SP original)
        public decimal Saldo_Consumo_MN =>
            Math.Round(Compras_Deb_MN - Interes_Corriente_MN + Saldo_Anterior_MN - Pagos_Cred_MN, 2);
        public decimal Saldo_Consumo_ME =>
            Math.Round(Compras_Deb_ME - Interes_Corriente_ME + Saldo_Anterior_ME - Pagos_Cred_ME, 2);
    }

    // ── Detalle crudo (RS2) ─────────────────────────────────────────────────
    public class DetalleRawDto
    {
        public string   No_Cuenta       { get; set; } = "";
        public DateTime? Fecha_Consumo  { get; set; }
        public string   Codigo_Mov      { get; set; } = "";
        public string   Descripcion_Mov { get; set; } = "";
        public string   Moneda_Mov      { get; set; } = "";   // "HN" | "DO"
        public string   TipoMovimiento  { get; set; } = "";   // "D" | "C"
        public decimal  Monto_Mov       { get; set; }
    }

    // ── Financiamiento crudo (RS3) ──────────────────────────────────────────
    public class FinanciamientoRawDto
    {
        public string   No_Cuenta            { get; set; } = "";
        public string   Tipo                 { get; set; } = "";
        public DateTime? FechaOtorgamiento   { get; set; }
        public decimal  ImporteTotalPlan     { get; set; }
        public string   MonedaMovimiento     { get; set; } = "";
        public decimal  Importe              { get; set; }
        public int      CantidadCuotasPlan   { get; set; }
        public int      NoCuotaLiquidada     { get; set; }
        public decimal  PlanExtraTasa        { get; set; }
        public decimal  PlanCuotaCapitalPend { get; set; }

        // Tasa formateada igual que el SP original
        public string TasaFormateada =>
            PlanExtraTasa == 0 ? "0%" : $"{PlanExtraTasa}%";
    }
}
