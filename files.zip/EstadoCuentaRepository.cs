using EstadosCuentaTC.Data;
using EstadosCuentaTC.Dtos;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace EstadosCuentaTC.Repositories
{
    public class EstadoCuentaRepository
    {
        private readonly SqlExecutor _sql;

        public EstadoCuentaRepository(SqlExecutor sql)
        {
            _sql = sql;
        }

        /// <summary>
        /// Ejecuta el SP y retorna los 3 datasets planos para que
        /// el service construya el JSON en memoria.
        /// </summary>
        public LoteDatosDto? ObtenerLote(int workerId)
        {
            using var conn = _sql.GetConnection();

            using var cmd = new SqlCommand("usp_SBEstadoCuentaJsonMasivo", conn)
            {
                CommandType    = CommandType.StoredProcedure,
                CommandTimeout = 0
            };

            cmd.Parameters.AddWithValue("@WorkerId", workerId);

            if (conn.State != ConnectionState.Open)
                conn.Open();

            using var reader = cmd.ExecuteReader();

            // ── Result set 1 ─ Encabezados ──────────────────────────────
            var encabezados = new List<EncabezadoDto>();

            // Si el SP devuelve 0 (bandeja vacía) el primer RS tiene 1 col "Resultado"
            if (reader.FieldCount == 1 && reader.GetName(0) == "Resultado")
                return null;

            while (reader.Read())
                encabezados.Add(MapEncabezado(reader));

            if (encabezados.Count == 0)
                return null;

            // ── Result set 2 ─ Detalle ──────────────────────────────────
            var detalles = new List<DetalleRawDto>();
            reader.NextResult();

            while (reader.Read())
                detalles.Add(MapDetalle(reader));

            // ── Result set 3 ─ Financiamientos ──────────────────────────
            var financiamientos = new List<FinanciamientoRawDto>();
            reader.NextResult();

            while (reader.Read())
                financiamientos.Add(MapFinanciamiento(reader));

            // ── Result set 4 ─ Tarjetas del lote ────────────────────────
            var tarjetas = new List<string>();
            reader.NextResult();

            while (reader.Read())
                tarjetas.Add(reader.GetString(0));

            return new LoteDatosDto
            {
                Encabezados     = encabezados,
                Detalles        = detalles,
                Financiamientos = financiamientos,
                Tarjetas        = tarjetas
            };
        }

        // ── Mappers ──────────────────────────────────────────────────────

        private static EncabezadoDto MapEncabezado(SqlDataReader r)
        {
            return new EncabezadoDto
            {
                No_Tarjeta           = r["No_Tarjeta"]?.ToString() ?? "",
                No_Cuenta            = r["No_Cuenta"]?.ToString()  ?? "",
                Origen               = Trim(r, "Origen"),
                Emisor               = Trim(r, "Emisor"),
                Nombre_TH_Tit        = Trim(r, "Nombre_TH_Tit"),
                Emisor_Madre         = Trim(r, "Emisor_Madre"),
                Cuenta_Madre         = Trim(r, "Cuenta_Madre"),
                Nombre_Empresa       = Trim(r, "Nombre_Empresa"),
                Tipo_Tarjeta         = Trim(r, "Tipo_Tarjeta"),
                Fecha_Pago           = r["Fecha_Pago"]   is DBNull ? null : Convert.ToDateTime(r["Fecha_Pago"]),
                Fecha_Corte          = r["Fecha_Corte"]  is DBNull ? null : Convert.ToDateTime(r["Fecha_Corte"]),
                Pago_Contado_MN      = Dec(r, "Pago_Contado_MN"),
                Pago_Minimo_MN       = Dec(r, "Pago_Minimo_MN"),
                Saldo_Vencido_MN     = Dec(r, "Saldo_Vencido_MN"),
                Saldo_Anterior_MN    = Dec(r, "Saldo_Anterior_MN"),
                Saldo_Final_MN       = Dec(r, "Saldo_Final_MN"),
                Compras_Deb_MN       = Dec(r, "Compras_Deb_MN"),
                Pagos_Cred_MN        = Dec(r, "Pagos_Cred_MN"),
                Sobregiro_MN         = Dec(r, "Sobregiro_MN"),
                Cuota_Mes_MN         = Dec(r, "Cuota_Mes_MN"),
                Pago_Contado_ME      = Dec(r, "Pago_Contado_ME"),
                Pago_Minimo_ME       = Dec(r, "Pago_Minimo_ME"),
                Saldo_Vencido_ME     = Dec(r, "Saldo_Vencido_ME"),
                Saldo_Anterior_ME    = Dec(r, "Saldo_Anterior_ME"),
                Saldo_Final_ME       = Dec(r, "Saldo_Final_ME"),
                Compras_Deb_ME       = Dec(r, "Compras_Deb_ME"),
                Pagos_Cred_ME        = Dec(r, "Pagos_Cred_ME"),
                Sobregiro_ME         = Dec(r, "Sobregiro_ME"),
                Cuota_Mes_ME         = Dec(r, "Cuota_Mes_ME"),
                Moneda_Lim_Cre       = Trim(r, "Moneda_Lim_Cre"),
                Limite_Credito       = Dec(r, "Limite_Credito"),
                Disponible_Cta_MN    = Dec(r, "Disponible_Cta_MN"),
                Disponible_Cta_ME    = Dec(r, "Disponible_Cta_ME"),
                Disponible_Ret_MN    = Dec(r, "Disponible_Ret_MN"),
                Disponible_Ret_ME    = Dec(r, "Disponible_Ret_ME"),
                PTS_Saldo_Ant        = Long(r, "PTS_Saldo_Ant"),
                PTS_Ganados          = Long(r, "PTS_Ganados"),
                PTS_Usuados          = Long(r, "PTS_Usuados"),
                PTS_Saldo_Actual     = Long(r, "PTS_Saldo_Actual"),
                Moneda_Lim_EF        = Trim(r, "Moneda_Lim_EF"),
                EF_Limite            = Dec(r, "EF_Limite"),
                EF_Saldo_MN          = Dec(r, "EF_Saldo_MN"),
                EF_Debitos_MN        = Dec(r, "EF_Debitos_MN"),
                EF_Creditos_MN       = Dec(r, "EF_Creditos_MN"),
                EF_Saldo_ME          = Dec(r, "EF_Saldo_ME"),
                EF_Debitos_ME        = Dec(r, "EF_Debitos_ME"),
                EF_Creditos_ME       = Dec(r, "EF_Creditos_ME"),
                EF_Disponible_MN     = Dec(r, "EF_Disponible_MN"),
                EF_Disponible_ME     = Dec(r, "EF_Disponible_ME"),
                Tasa_Int_Anual_MN    = Dec(r, "Tasa_Int_Anual_MN"),
                Tasa_Int_Anual_ME    = Dec(r, "Tasa_Int_Anual_ME"),
                Direccion_1          = Trim(r, "Direccion_1"),
                Direccion_2          = Trim(r, "Direccion_2"),
                Direccion_3          = Trim(r, "Direccion_3"),
                Apdo_Postal          = Trim(r, "Apdo_Postal"),
                Ciudad               = Trim(r, "Ciudad"),
                Mensaje_1            = Trim(r, "Mensaje_1"),
                Mensaje_2            = Trim(r, "Mensaje_2"),
                Mensaje_3            = Trim(r, "Mensaje_3"),
                Mensaje_4            = Trim(r, "Mensaje_4"),
                Mensaje_5            = Trim(r, "Mensaje_5"),
                Tarjeta_Imprimir     = Trim(r, "Tarjeta_Imprimir"),
                Costo_Anual_Tot_MN   = Dec(r, "Costo_Anual_Tot_MN"),
                Costo_Anual_Tot_ME   = Dec(r, "Costo_Anual_Tot_ME"),
                Plazo_Canc_Deuda_MN  = Int(r, "Plazo_Canc_Deuda_MN"),
                Plazo_Canc_Deuda_ME  = Int(r, "Plazo_Canc_Deuda_ME"),
                Interes_Pago_Min_MN  = Dec(r, "Interes_Pago_Min_MN"),
                Interes_Pago_Min_ME  = Dec(r, "Interes_Pago_Min_ME"),
                Correo               = Trim(r, "Correo"),
                Limite_CreditoMN     = Dec(r, "Limite_CreditoMN"),
                Interes_Corriente_MN = Dec(r, "Interes_Corriente_MN"),
                Interes_Corriente_ME = Dec(r, "Interes_Corriente_ME"),
                EstadoTarjeta        = Trim(r, "EstadoTarjeta")
            };
        }

        private static DetalleRawDto MapDetalle(SqlDataReader r) => new()
        {
            No_Cuenta       = r["No_Cuenta"]?.ToString() ?? "",
            Fecha_Consumo   = r["Fecha_Consumo"] is DBNull ? null : Convert.ToDateTime(r["Fecha_Consumo"]),
            Codigo_Mov      = r["Codigo_Mov"]?.ToString()      ?? "",
            Descripcion_Mov = r["Descripcion_Mov"]?.ToString() ?? "",
            Moneda_Mov      = r["Moneda_Mov"]?.ToString()      ?? "",
            TipoMovimiento  = r["TipoMovimiento"]?.ToString()  ?? "",
            Monto_Mov       = r["Monto_Mov"] is DBNull ? 0m : Convert.ToDecimal(r["Monto_Mov"])
        };

        private static FinanciamientoRawDto MapFinanciamiento(SqlDataReader r) => new()
        {
            No_Cuenta            = r["No_Cuenta"]?.ToString()        ?? "",
            Tipo                 = r["Tipo"]?.ToString()             ?? "",
            FechaOtorgamiento    = r["FechaOtorgamiento"] is DBNull ? null : Convert.ToDateTime(r["FechaOtorgamiento"]),
            ImporteTotalPlan     = r["ImporteTotalPlan"]  is DBNull ? 0m   : Convert.ToDecimal(r["ImporteTotalPlan"]),
            MonedaMovimiento     = r["MonedaMovimiento"]?.ToString() ?? "",
            Importe              = r["Importe"]           is DBNull ? 0m   : Convert.ToDecimal(r["Importe"]),
            CantidadCuotasPlan   = r["CantidadCuotasPlan"] is DBNull ? 0  : Convert.ToInt32(r["CantidadCuotasPlan"]),
            NoCuotaLiquidada     = r["NoCuotaLiquidada"]  is DBNull ? 0   : Convert.ToInt32(r["NoCuotaLiquidada"]),
            PlanExtraTasa        = r["PlanExtraTasa"]      is DBNull ? 0m  : Convert.ToDecimal(r["PlanExtraTasa"]),
            PlanCuotaCapitalPend = r["PlanCuotaCapitalPend"] is DBNull ? 0m : Convert.ToDecimal(r["PlanCuotaCapitalPend"])
        };

        // ── Helpers de lectura segura ─────────────────────────────────────
        private static string  Trim(SqlDataReader r, string col) => r[col] is DBNull ? "" : r[col].ToString()!.Trim();
        private static decimal Dec (SqlDataReader r, string col) => r[col] is DBNull ? 0m  : Convert.ToDecimal(r[col]);
        private static int     Int (SqlDataReader r, string col) => r[col] is DBNull ? 0   : Convert.ToInt32(r[col]);
        private static long    Long(SqlDataReader r, string col) => r[col] is DBNull ? 0L  : Convert.ToInt64(r[col]);
    }
}
