using EstadosCuentaTC.Dtos;
using EstadosCuentaTC.Repositories;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.Tasks;

namespace EstadosCuentaTC.Services
{
    public class GeneracionLoteService
    {
        private readonly EstadoCuentaRepository _repo;
        private readonly ILogger<GeneracionLoteService> _logger;

        // Protege la escritura al archivo compartido
        private static readonly object _lockFile = new();

        // Controla si ya se escribió el primer fragmento (para la coma separadora)
        private bool _primerFragmento = true;
        private static readonly object _lockPrimer = new();

        // Opciones de serialización: sin escapes innecesarios, sin indentar
        private static readonly JsonSerializerOptions _jsonOpts = new()
        {
            Encoder       = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            WriteIndented = false
        };

        public GeneracionLoteService(
            EstadoCuentaRepository repo,
            ILogger<GeneracionLoteService> logger)
        {
            _repo   = repo;
            _logger = logger;
        }

        public void Ejecutar(string rutaBase, DateTime fechaCorte, int cantidadHilos)
        {
            var ruta = Path.Combine(rutaBase, fechaCorte.ToString("yyyy-MM-dd"));
            Directory.CreateDirectory(ruta);

            var archivoJson = Path.Combine(
                ruta,
                $"Estado_de_cuenta_{fechaCorte:yyyyMMdd}.json"
            );

            // Inicia el objeto JSON
            File.WriteAllText(archivoJson, "{", Encoding.UTF8);
            _primerFragmento = true;

            _logger.LogInformation("Iniciando con {Hilos} workers...", cantidadHilos);

            var tareas = new Task[cantidadHilos];

            for (int i = 0; i < cantidadHilos; i++)
            {
                int workerId = i + 1;

                tareas[i] = Task.Run(() =>
                {
                    _logger.LogInformation("Worker {Id} iniciado", workerId);

                    while (true)
                    {
                        try
                        {
                            // 1. Obtener lote de datos planos desde SQL
                            var lote = _repo.ObtenerLote(workerId);

                            // Sin más registros → terminar
                            if (lote == null)
                                break;

                            // 2. Construir el fragmento JSON en memoria
                            var fragmento = ConstruirFragmento(lote);

                            if (string.IsNullOrEmpty(fragmento))
                                continue;

                            // 3. Escribir en el archivo con lock
                            lock (_lockFile)
                            {
                                string prefijo;
                                lock (_lockPrimer)
                                {
                                    prefijo          = _primerFragmento ? "" : ",";
                                    _primerFragmento = false;
                                }

                                File.AppendAllText(archivoJson,
                                    prefijo + fragmento, Encoding.UTF8);
                            }

                            _logger.LogInformation(
                                "Worker {Id} procesó {N} tarjetas",
                                workerId, lote.Tarjetas.Count);
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "Error en worker {Id}", workerId);
                            break;
                        }
                    }

                    _logger.LogInformation("Worker {Id} finalizado", workerId);
                });
            }

            Task.WaitAll(tareas);

            // Cierra el objeto JSON
            File.AppendAllText(archivoJson, "}", Encoding.UTF8);

            _logger.LogInformation("Proceso finalizado. Archivo: {Ruta}", archivoJson);
        }

        // ── Constructor de JSON ──────────────────────────────────────────────

        /// <summary>
        /// Dado un lote con 3 listas planas, construye el fragmento JSON:
        ///   "XXXXXXXXXXXXXXXX": { "Encabezado": {...}, "Detalle": [...], "Financiamientos": [...] },
        ///   "YYYYYYYYYYYYYYYY": { ... }
        /// SIN las llaves externas { } — esas las maneja el archivo.
        /// </summary>
        private string ConstruirFragmento(LoteDatosDto lote)
        {
            if (lote.Encabezados.Count == 0)
                return "";

            // Indexar detalle y financiamientos por No_Cuenta para O(1)
            var detallesPorCuenta = lote.Detalles
                .GroupBy(d => d.No_Cuenta)
                .ToDictionary(g => g.Key, g => g.ToList());

            var finanPorCuenta = lote.Financiamientos
                .GroupBy(f => f.No_Cuenta)
                .ToDictionary(g => g.Key, g => g.ToList());

            var sb = new StringBuilder();
            bool primero = true;

            foreach (var enc in lote.Encabezados)
            {
                if (!primero) sb.Append(',');
                primero = false;

                var detalle        = detallesPorCuenta.GetValueOrDefault(enc.No_Cuenta, []);
                var financiamiento = finanPorCuenta   .GetValueOrDefault(enc.No_Cuenta, []);

                // Clave del objeto raíz
                sb.Append('"');
                sb.Append(enc.No_Tarjeta);
                sb.Append("\":");

                using var ms     = new MemoryStream();
                using var writer = new Utf8JsonWriter(ms, new JsonWriterOptions
                {
                    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                });

                writer.WriteStartObject();

                // ── Encabezado ───────────────────────────────────────────
                writer.WritePropertyName("Encabezado");
                EscribirEncabezado(writer, enc);

                // ── Detalle ──────────────────────────────────────────────
                writer.WritePropertyName("Detalle");
                EscribirDetalle(writer, detalle);

                // ── Financiamientos ──────────────────────────────────────
                writer.WritePropertyName("Financiamientos");
                EscribirFinanciamientos(writer, financiamiento);

                writer.WriteEndObject();
                writer.Flush();

                sb.Append(Encoding.UTF8.GetString(ms.ToArray()));
            }

            return sb.ToString();
        }

        private static void EscribirEncabezado(Utf8JsonWriter w, EncabezadoDto e)
        {
            w.WriteStartObject();
            w.WriteString ("Origen",               e.Origen);
            w.WriteString ("Emisor",               e.Emisor);
            w.WriteString ("No_Cuenta",            e.No_Cuenta);
            w.WriteString ("Nombre_TH_Tit",        e.Nombre_TH_Tit);
            w.WriteString ("Emisor_Madre",         e.Emisor_Madre);
            w.WriteString ("Cuenta_Madre",         e.Cuenta_Madre);
            w.WriteString ("Nombre_Empresa",       e.Nombre_Empresa);
            w.WriteString ("Tipo_Tarjeta",         e.Tipo_Tarjeta);
            w.WriteString ("No_Tarjeta",           e.No_Tarjeta);
            w.WriteString ("Fecha_Pago",           e.Fecha_Pago?.ToString("dd/MM/yyyy") ?? "");
            w.WriteString ("Fecha_Corte",          e.Fecha_Corte?.ToString("dd/MM/yyyy") ?? "");
            w.WriteNumber ("Pago_Contado_MN",      e.Pago_Contado_MN);
            w.WriteNumber ("Pago_Minimo_MN",       e.Pago_Minimo_MN);
            w.WriteNumber ("Saldo_Vencido_MN",     e.Saldo_Vencido_MN);
            w.WriteNumber ("Saldo_Anterior_MN",    e.Saldo_Anterior_MN);
            w.WriteNumber ("Saldo_Final_MN",       e.Saldo_Final_MN);
            w.WriteNumber ("Compras_Deb_MN",       e.Compras_Deb_MN);
            w.WriteNumber ("Pagos_Cred_MN",        e.Pagos_Cred_MN);
            w.WriteNumber ("Sobregiro_MN",         e.Sobregiro_MN);
            w.WriteNumber ("Cuota_Mes_MN",         e.Cuota_Mes_MN);
            w.WriteNumber ("Pago_Contado_ME",      e.Pago_Contado_ME);
            w.WriteNumber ("Pago_Minimo_ME",       e.Pago_Minimo_ME);
            w.WriteNumber ("Saldo_Vencido_ME",     e.Saldo_Vencido_ME);
            w.WriteNumber ("Saldo_Anterior_ME",    e.Saldo_Anterior_ME);
            w.WriteNumber ("Saldo_Final_ME",       e.Saldo_Final_ME);
            w.WriteNumber ("Saldo_Consumo_MN",     e.Saldo_Consumo_MN);
            w.WriteNumber ("Saldo_Consumo_ME",     e.Saldo_Consumo_ME);
            w.WriteNumber ("Compras_Deb_ME",       e.Compras_Deb_ME);
            w.WriteNumber ("Pagos_Cred_ME",        e.Pagos_Cred_ME);
            w.WriteNumber ("Sobregiro_ME",         e.Sobregiro_ME);
            w.WriteNumber ("Cuota_Mes_ME",         e.Cuota_Mes_ME);
            w.WriteString ("Moneda_Lim_Cre",       e.Moneda_Lim_Cre);
            w.WriteNumber ("Limite_Credito",       e.Limite_Credito);
            w.WriteNumber ("Disponible_Cta_MN",    e.Disponible_Cta_MN);
            w.WriteNumber ("Disponible_Cta_ME",    e.Disponible_Cta_ME);
            w.WriteNumber ("Disponible_Ret_MN",    e.Disponible_Ret_MN);
            w.WriteNumber ("Disponible_Ret_ME",    e.Disponible_Ret_ME);
            w.WriteNumber ("PTS_Saldo_Ant",        e.PTS_Saldo_Ant);
            w.WriteNumber ("PTS_Ganados",          e.PTS_Ganados);
            w.WriteNumber ("PTS_Usuados",          e.PTS_Usuados);
            w.WriteNumber ("PTS_Saldo_Actual",     e.PTS_Saldo_Actual);
            w.WriteString ("Moneda_Lim_EF",        e.Moneda_Lim_EF);
            w.WriteNumber ("EF_Limite",            e.EF_Limite);
            w.WriteNumber ("EF_Saldo_MN",          e.EF_Saldo_MN);
            w.WriteNumber ("EF_Debitos_MN",        e.EF_Debitos_MN);
            w.WriteNumber ("EF_Creditos_MN",       e.EF_Creditos_MN);
            w.WriteNumber ("EF_Saldo_ME",          e.EF_Saldo_ME);
            w.WriteNumber ("EF_Debitos_ME",        e.EF_Debitos_ME);
            w.WriteNumber ("EF_Creditos_ME",       e.EF_Creditos_ME);
            w.WriteNumber ("EF_Disponible_MN",     e.EF_Disponible_MN);
            w.WriteNumber ("EF_Disponible_ME",     e.EF_Disponible_ME);
            w.WriteNumber ("Tasa_Int_Anual_MN",    e.Tasa_Int_Anual_MN);
            w.WriteNumber ("Tasa_Int_Anual_ME",    e.Tasa_Int_Anual_ME);
            w.WriteString ("Direccion_1",          e.Direccion_1);
            w.WriteString ("Direccion_2",          e.Direccion_2);
            w.WriteString ("Direccion_3",          e.Direccion_3);
            w.WriteString ("Apdo_Postal",          e.Apdo_Postal);
            w.WriteString ("Ciudad",               e.Ciudad);
            w.WriteString ("Mensaje_1",            e.Mensaje_1);
            w.WriteString ("Mensaje_2",            e.Mensaje_2);
            w.WriteString ("Mensaje_3",            e.Mensaje_3);
            w.WriteString ("Mensaje_4",            e.Mensaje_4);
            w.WriteString ("Mensaje_5",            e.Mensaje_5);
            w.WriteString ("Tarjeta_Imprimir",     e.Tarjeta_Imprimir);
            w.WriteNumber ("Costo_Anual_Tot_MN",   e.Costo_Anual_Tot_MN);
            w.WriteNumber ("Costo_Anual_Tot_ME",   e.Costo_Anual_Tot_ME);
            w.WriteNumber ("Plazo_Canc_Deuda_MN",  e.Plazo_Canc_Deuda_MN);
            w.WriteNumber ("Plazo_Canc_Deuda_ME",  e.Plazo_Canc_Deuda_ME);
            w.WriteNumber ("Interes_Pago_Min_MN",  e.Interes_Pago_Min_MN);
            w.WriteNumber ("Interes_Pago_Min_ME",  e.Interes_Pago_Min_ME);
            w.WriteString ("Correo",               e.Correo);
            w.WriteNumber ("Limite_CreditoMN",     e.Limite_CreditoMN);
            w.WriteNumber ("Interes_Corriente_MN", e.Interes_Corriente_MN);
            w.WriteNumber ("Interes_Corriente_ME", e.Interes_Corriente_ME);
            w.WriteString ("Estado",               e.EstadoTarjeta);
            w.WriteEndObject();
        }

        private static void EscribirDetalle(Utf8JsonWriter w, List<DetalleRawDto> movs)
        {
            w.WriteStartArray();

            // Movimientos (Tipo_Reg = 1)
            foreach (var m in movs.OrderBy(x => x.Fecha_Consumo))
            {
                w.WriteStartObject();
                w.WriteString("Fecha_Consumo",   m.Fecha_Consumo?.ToString("dd/MM/yyyy") ?? "");
                w.WriteNumber("Tipo_Reg",         1);
                w.WriteString("Descripcion_Mov",  m.Descripcion_Mov.Trim());
                w.WriteNumber("DebitosMN",  m.Moneda_Mov == "HN" && m.TipoMovimiento == "D" ? m.Monto_Mov : 0);
                w.WriteNumber("CreditosMN", m.Moneda_Mov == "HN" && m.TipoMovimiento == "C" ? m.Monto_Mov : 0);
                w.WriteNumber("DebitosME",  m.Moneda_Mov == "DO" && m.TipoMovimiento == "D" ? m.Monto_Mov : 0);
                w.WriteNumber("CreditosME", m.Moneda_Mov == "DO" && m.TipoMovimiento == "C" ? m.Monto_Mov : 0);
                w.WriteEndObject();
            }

            // Subtotal (Tipo_Reg = 2)
            w.WriteStartObject();
            w.WriteString("Fecha_Consumo",  "");
            w.WriteNumber("Tipo_Reg",        2);
            w.WriteString("Descripcion_Mov", "Subtotal");
            w.WriteNumber("DebitosMN",  movs.Where(x => x.Moneda_Mov == "HN" && x.TipoMovimiento == "D").Sum(x => x.Monto_Mov));
            w.WriteNumber("CreditosMN", movs.Where(x => x.Moneda_Mov == "HN" && x.TipoMovimiento == "C").Sum(x => x.Monto_Mov));
            w.WriteNumber("DebitosME",  movs.Where(x => x.Moneda_Mov == "DO" && x.TipoMovimiento == "D").Sum(x => x.Monto_Mov));
            w.WriteNumber("CreditosME", movs.Where(x => x.Moneda_Mov == "DO" && x.TipoMovimiento == "C").Sum(x => x.Monto_Mov));
            w.WriteEndObject();

            // Total (Tipo_Reg = 3)
            w.WriteStartObject();
            w.WriteString("Fecha_Consumo",  "");
            w.WriteNumber("Tipo_Reg",        3);
            w.WriteString("Descripcion_Mov", "Total");
            w.WriteNumber("DebitosMN",  movs.Sum(x => x.Monto_Mov));
            w.WriteNumber("CreditosMN", 0m);
            w.WriteNumber("DebitosME",  0m);
            w.WriteNumber("CreditosME", 0m);
            w.WriteEndObject();

            w.WriteEndArray();
        }

        private static void EscribirFinanciamientos(Utf8JsonWriter w, List<FinanciamientoRawDto> items)
        {
            w.WriteStartArray();

            foreach (var f in items)
            {
                w.WriteStartObject();
                w.WriteString("Tipo",               f.Tipo);
                w.WriteString("Fecha",              f.FechaOtorgamiento?.ToString("dd/MM/yyyy") ?? "");
                w.WriteNumber("Monto",              f.ImporteTotalPlan);
                w.WriteString("Moneda",             f.MonedaMovimiento);
                w.WriteNumber("Cuota",              f.Importe);
                w.WriteNumber("Plazo",              f.CantidadCuotasPlan);
                w.WriteNumber("CuotaAplicada",      f.NoCuotaLiquidada);
                w.WriteString("Tasa",               f.TasaFormateada);
                w.WriteNumber("Saldo",              f.PlanCuotaCapitalPend);
                w.WriteEndObject();
            }

            w.WriteEndArray();
        }
    }
}
